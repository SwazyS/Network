
import UIKit

class UserActionCell: UICollectionViewCell {
    
    @IBOutlet var userActionLabel: UILabel!
}


